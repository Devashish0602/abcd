# QT-Converter
As a small exercise to learn QT I made a (bidirectional) converter between two currencies.

The [fixer.io](http://fixer.io) APIs are used to get the current foreign exchange (forex) rates published by the European Central Bank.


## Instructions
Windows: open the `.pro` file with Qt Creator.


## Made with
- Qt Creator 4.5.1
- Qt 5.10.1
- Windows 10
